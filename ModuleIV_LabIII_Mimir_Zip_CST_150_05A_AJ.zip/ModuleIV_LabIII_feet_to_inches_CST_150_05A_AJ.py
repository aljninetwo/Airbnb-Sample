#input
#function that converts feet to inches

def feet_to_inches (x):
    return x*12

def feet ():
    x = int(input('Enter feet : '))
    return x

def disp_inches(x):
    #Print the number of inches as results
    print('Number of inches :',x)


x = feet()
x = feet_to_inches(x)
disp_inches(x)


    
